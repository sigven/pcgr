.. PCGR documentation master file, created by
   sphinx-quickstart on Thu Feb 16 12:29:15 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to PCGR's documentation!
===========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   about
   getting_started
   FAQ
   annotation_resources
   input
   output
      tier_systems

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
