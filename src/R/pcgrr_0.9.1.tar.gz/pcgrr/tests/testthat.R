library(testthat)
library(pcgrr)

context("Biomarker check")
pcgr_data <- readRDS(file='/Users/sigven/research/databundle/pcgr/20201029/data/grch37/rds/pcgr_data.rds')

test_that("str_length of factor is length of level", {
  expect_equal(str_length(factor("a")), 1)
  expect_equal(str_length(factor("ab")), 2)
  expect_equal(str_length(factor("abc")), 3)
})
